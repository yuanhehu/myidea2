create view ac as
  select
    date_format(`abc`.`t_sale`.`sale_date`, '%Y-%m') AS `date_format(sale_date,'%Y-%m')`,
    sum(`abc`.`t_sale`.`sale_amount`)                AS `s`,
    `abc`.`t_sale`.`emp_id`                          AS `emp_id`
  from `abc`.`t_sale`
  group by date_format(`abc`.`t_sale`.`sale_date`, '%Y-%m'), `abc`.`t_sale`.`emp_id`;

