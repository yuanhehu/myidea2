create view emp as
  select
    date_format(`s`.`sale_date`, '%Y-%m') AS `yuefen`,
    `e`.`emp_name`                        AS `name`,
    sum(`s`.`sale_amount`)                AS `qiuhe`
  from (`abc`.`t_employ` `e`
    join `abc`.`t_sale` `s` on ((`e`.`id` = `s`.`emp_id`)))
  group by date_format(`s`.`sale_date`, '%Y-%m'), `e`.`emp_name`;

